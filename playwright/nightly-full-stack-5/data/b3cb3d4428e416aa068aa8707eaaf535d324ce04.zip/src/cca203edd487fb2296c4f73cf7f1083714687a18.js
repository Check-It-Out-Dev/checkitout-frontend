// Generated from: e2e-tests/bdd/features/account-activation-e2e.feature
import { test } from "../../../../e2e-tests/bdd/steps/fixtures.ts";

test.describe('Account Activation Notifications (NTF-003)', () => {

  test('Company receives ACCOUNT_ACTIVATED notification after email verified and company data confirmed', { tag: ['@notification-e2e', '@account-activation', '@company'] }, async ({ Given, When, Then, And, playwright, world }) => { 
    await Given('registry stubs are reset', null, { playwright, world }); 
    await And('a KRS company is configured for NIP "5261040828"', null, { playwright, world }); 
    await And('a COMPANY user is authenticated for registry tests', null, { playwright, world }); 
    await And('the registry user has emailVerified set to true', null, { world }); 
    await And('the registry user account status is set to "IN_VALIDATION"', null, { world }); 
    await When('the user performs a registry lookup for NIP "5261040828"', null, { world }); 
    await Then('the response status should be 200', null, { world }); 
    await When('the user confirms company data for NIP "5261040828"', null, { world }); 
    await Then('the response status should be 200', null, { world }); 
    await And('the confirm response activated should be true', null, { world }); 
    await And('the confirm response accountStatus should be "ACTIVE"', null, { world }); 
    await When('the registry user refreshes their session after activation', null, { playwright, world }); 
    await When('the registry user checks unread notification count', null, { world }); 
    await Then('the unread count should be at least 1', null, { world }); 
    await When('the registry user fetches notifications page 0 size 10', null, { world }); 
    await Then('the response status should be 200', null, { world }); 
    await And('the notifications response should contain type "ACCOUNT_ACTIVATED"', null, { world }); 
  });

});

// == technical section ==

test.beforeEach('BeforeEach Hooks', ({ $runScenarioHooks, page }) => $runScenarioHooks('before', { page }));
test.afterEach('AfterEach Hooks', ({ $runScenarioHooks, world }) => $runScenarioHooks('after', { world }));

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('e2e-tests/bdd/features/account-activation-e2e.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":6,"pickleLine":27,"tags":["@notification-e2e","@account-activation","@company"],"steps":[{"pwStepLine":7,"gherkinStepLine":28,"keywordType":"Context","textWithKeyword":"Given registry stubs are reset","stepMatchArguments":[]},{"pwStepLine":8,"gherkinStepLine":29,"keywordType":"Context","textWithKeyword":"And a KRS company is configured for NIP \"5261040828\"","stepMatchArguments":[{"group":{"start":36,"value":"\"5261040828\"","children":[{"start":37,"value":"5261040828","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":9,"gherkinStepLine":30,"keywordType":"Context","textWithKeyword":"And a COMPANY user is authenticated for registry tests","stepMatchArguments":[{"group":{"start":2,"value":"COMPANY"}}]},{"pwStepLine":10,"gherkinStepLine":31,"keywordType":"Context","textWithKeyword":"And the registry user has emailVerified set to true","stepMatchArguments":[{"group":{"start":43,"value":"true"},"parameterTypeName":"word"}]},{"pwStepLine":11,"gherkinStepLine":34,"keywordType":"Context","textWithKeyword":"And the registry user account status is set to \"IN_VALIDATION\"","stepMatchArguments":[{"group":{"start":43,"value":"\"IN_VALIDATION\"","children":[{"start":44,"value":"IN_VALIDATION","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":12,"gherkinStepLine":36,"keywordType":"Action","textWithKeyword":"When the user performs a registry lookup for NIP \"5261040828\"","stepMatchArguments":[{"group":{"start":44,"value":"\"5261040828\"","children":[{"start":45,"value":"5261040828","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":13,"gherkinStepLine":37,"keywordType":"Outcome","textWithKeyword":"Then the response status should be 200","stepMatchArguments":[{"group":{"start":30,"value":"200"},"parameterTypeName":"int"}]},{"pwStepLine":14,"gherkinStepLine":39,"keywordType":"Action","textWithKeyword":"When the user confirms company data for NIP \"5261040828\"","stepMatchArguments":[{"group":{"start":39,"value":"\"5261040828\"","children":[{"start":40,"value":"5261040828","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":15,"gherkinStepLine":40,"keywordType":"Outcome","textWithKeyword":"Then the response status should be 200","stepMatchArguments":[{"group":{"start":30,"value":"200"},"parameterTypeName":"int"}]},{"pwStepLine":16,"gherkinStepLine":41,"keywordType":"Outcome","textWithKeyword":"And the confirm response activated should be true","stepMatchArguments":[{"group":{"start":41,"value":"true"},"parameterTypeName":"word"}]},{"pwStepLine":17,"gherkinStepLine":42,"keywordType":"Outcome","textWithKeyword":"And the confirm response accountStatus should be \"ACTIVE\"","stepMatchArguments":[{"group":{"start":45,"value":"\"ACTIVE\"","children":[{"start":46,"value":"ACTIVE","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":18,"gherkinStepLine":45,"keywordType":"Action","textWithKeyword":"When the registry user refreshes their session after activation","stepMatchArguments":[]},{"pwStepLine":19,"gherkinStepLine":48,"keywordType":"Action","textWithKeyword":"When the registry user checks unread notification count","stepMatchArguments":[]},{"pwStepLine":20,"gherkinStepLine":49,"keywordType":"Outcome","textWithKeyword":"Then the unread count should be at least 1","stepMatchArguments":[{"group":{"start":36,"value":"1"},"parameterTypeName":"int"}]},{"pwStepLine":21,"gherkinStepLine":50,"keywordType":"Action","textWithKeyword":"When the registry user fetches notifications page 0 size 10","stepMatchArguments":[{"group":{"start":45,"value":"0"},"parameterTypeName":"int"},{"group":{"start":52,"value":"10"},"parameterTypeName":"int"}]},{"pwStepLine":22,"gherkinStepLine":51,"keywordType":"Outcome","textWithKeyword":"Then the response status should be 200","stepMatchArguments":[{"group":{"start":30,"value":"200"},"parameterTypeName":"int"}]},{"pwStepLine":23,"gherkinStepLine":52,"keywordType":"Outcome","textWithKeyword":"And the notifications response should contain type \"ACCOUNT_ACTIVATED\"","stepMatchArguments":[{"group":{"start":47,"value":"\"ACCOUNT_ACTIVATED\"","children":[{"start":48,"value":"ACCOUNT_ACTIVATED","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
]; // bdd-data-end